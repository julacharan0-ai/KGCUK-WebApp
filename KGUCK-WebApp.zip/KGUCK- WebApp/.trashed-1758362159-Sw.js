// Simple function to add announcements
function addAnnouncement(text){
  let ul = document.getElementById("announcement-list");
  let li = document.createElement("li");
  li.textContent = text;
  ul.appendChild(li);
}