const cacheName = 'kguck-cache-v1';
const assetsToCache = ['/', 'index.html', 'style.css', 'manifest.json', 'ganesh_song.mp3'];

self.addEventListener('install', e => { e.waitUntil(caches.open(cacheName).then(c => c.addAll(assetsToCache))); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(keys => Promise.all(keys.map(k => { if(k!==cacheName){return caches.delete(k);} })))); });
self.addEventListener('fetch', e => { e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))); });